package com.java.test;

public class LeaveException extends Exception {

	public LeaveException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LeaveException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

package com.java.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.java.studentfiles.Student;

public class LeaveDetailsDAO {
	
	static List<LeaveDetails> lstLeaveDetails;
	
	static {
		lstLeaveDetails = new ArrayList<LeaveDetails>();
	}
	
	
	public String addLeaveDetailsDAO(LeaveDetails ld)
	{
		lstLeaveDetails.add(ld);
		return "Leave added successfully";
	}
	
	public List<LeaveDetails> showLeaveDetailsDAO() {
		return lstLeaveDetails;
	}
	
	public LeaveDetails searchLeaveDetailsDAO(int empid) {
		LeaveDetails result = null;
		for (LeaveDetails ld : lstLeaveDetails) {
			if (ld.getEmpId()==empid) {
				result=ld;
				break;
			}
		}
		return result;
	}
	
	public String deleteLeaveDetailsDAO(int empid) {
		LeaveDetails ld = searchLeaveDetailsDAO(empid);
		if (ld != null) {
			lstLeaveDetails.remove(ld);
			return "Leave Record Deleted Successfully";
		} 
		return "Leave Record Not Found";
	}
	
	public String updateLeaveDetailsDAO(LeaveDetails ldnew) {
		LeaveDetails ldold = searchLeaveDetailsDAO(ldnew.getEmpId());
		if (ldold != null) {
			ldold.setEmpId(ldnew.getEmpId());
			ldold.setLeaveAppliedOn(ldnew.getLeaveAppliedOn());
			ldold.setLeaveStartDate(ldnew.getLeaveStartDate());
			ldold.setLeaveEndDate(ldnew.getLeaveEndDate());
			ldold.setLeaveReason(ldnew.getLeaveReason());
			ldold.setLeaveId(ldnew.getLeaveId());
			ldold.setNoOfDays(ldnew.getNoOfDays());
			
			return "Record Updated Successfully";
		}
		return "Leave Record Not Found";
		
	}
	
	public String readLeaveDetailsDAO() throws IOException, ClassNotFoundException {
		FileInputStream fin = new FileInputStream("c:/files/LeaveDetails.txt");
		ObjectInputStream objin = new ObjectInputStream(fin);
		lstLeaveDetails = (List<LeaveDetails>)objin.readObject(); 
		objin.close();
		fin.close();
		return "File Read Successfully";
	}
	
	public String writeLeaveDetailsDAO() throws IOException {
		FileOutputStream fout = new FileOutputStream("c:/files/LeaveDetails.txt");
		ObjectOutputStream objout = new ObjectOutputStream(fout);
		objout.writeObject(lstLeaveDetails);
		objout.close();
		fout.close();
		return "File Write Successfully";
	}

}
